package  com.example.apifragmentproject.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.apifragmentproject.ApiRequest.Api
import com.example.apifragmentproject.`interface`.RetrofitService
import com.example.apifragmentproject.adapter.MovieAdapter
import com.example.apifragmentproject.databinding.FragmentHomeBinding
import com.example.apifragmentproject.model.Movie
import com.example.apifragmentproject.model.MovieResponse
import kotlinx.android.synthetic.main.fragment_home.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

const val TAG = "HomeFragment"

class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding

    private lateinit var homeAdapter: MovieAdapter




    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentHomeBinding.inflate(layoutInflater)

        return binding.root
    }





    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerview.layoutManager =GridLayoutManager(context,2)
        recyclerview.setHasFixedSize(true)
        getMovieData { movies : List<Movie> ->
            recyclerview.adapter = MovieAdapter(movies)
        }

    }






    private fun getMovieData(callback: (List<Movie>) -> Unit){
        val apiService = Api.getInstance().create(RetrofitService::class.java)
        apiService.getMovieList().enqueue(object : Callback<MovieResponse> {
            override fun onFailure(call: Call<MovieResponse>, t: Throwable) {

            }

            override fun onResponse(call: Call<MovieResponse>, response: Response<MovieResponse>) {
                return callback(response.body()!!.movies)
            }

        })
    }
    }




