package com.example.apifragmentproject.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.apifragmentproject.R
import com.example.apifragmentproject.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth


class ProfileFragment : Fragment() {
    private lateinit var binding: FragmentProfileBinding
    private lateinit var firebaseAuth: FirebaseAuth


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentProfileBinding.inflate(layoutInflater)
        firebaseAuth = FirebaseAuth.getInstance()

        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
checkUser(view)
        binding.logout.setOnClickListener{
            firebaseAuth.signOut()
            checkUser(view)
        }
        }

     fun checkUser(view:View) {
         val firebaseUser = firebaseAuth.currentUser
         if (firebaseUser != null) {
             val emaill = firebaseUser.email
             binding.email.text = emaill
         } else {
             navigateFragments(view, R.id.action_profileFragment_to_loginFragment)
         }
     }




         private fun navigateFragments(view: View, frag: Int) {
             Navigation.findNavController(view)
                 .navigate(frag)
         }


}