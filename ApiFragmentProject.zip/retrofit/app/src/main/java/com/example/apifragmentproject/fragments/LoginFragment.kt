package  com.example.apifragmentproject.fragments

import android.app.ProgressDialog
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.Navigation
import com.example.apifragmentproject.R
import com.example.apifragmentproject.databinding.FragmentLoginBinding
import com.google.firebase.auth.FirebaseAuth

class LoginFragment : Fragment() {
    private lateinit var progressDialog: ProgressDialog
    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var binding: FragmentLoginBinding
    private var email = ""
    private var password = ""


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentLoginBinding.inflate(layoutInflater)


        //configure progress Dialog
        progressDialog = ProgressDialog(context)
        progressDialog.setTitle("Please wait")
        progressDialog.setMessage("logging in..")
        progressDialog.setCanceledOnTouchOutside((false))

        //init firebaseAuth
        firebaseAuth = FirebaseAuth.getInstance()



        return binding.root


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
       checkUser(view)
        binding.Login.setOnClickListener {

            //b4 loggin vvalidate data
            validateData(view)
        }


        binding.Register.setOnClickListener {
            navigateFragments(view, R.id.action_loginFragment_to_signUpFragment)
        }


    }

   private fun checkUser(view: View) {
        val firebaseUser = firebaseAuth.currentUser
        //if user exists navigate to favorite fragment
        if (firebaseUser != null) {
            navigateFragments(view, R.id.action_loginFragment_to_homeFragment)
        }
    }

    private fun navigateFragments(view: View, frag: Int) {
        Navigation.findNavController(view)
            .navigate(frag)
    }

   private fun validateData(view:View) {
        email = binding.email.text.toString().trim()
        password = binding.password.text.toString().trim()
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.email.error = "Invalid email format"
        } else if (TextUtils.isEmpty(password)) {
            binding.password.error = "Please enter password"
        } else {
            //login
            firebaseLogin(view)

        }
    }


    private fun firebaseLogin(view: View) {
        progressDialog.show()
        firebaseAuth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                progressDialog.dismiss()
                val firebaseUser = firebaseAuth.currentUser
                val email = firebaseUser!!.email
                Toast.makeText(context, "account created", Toast.LENGTH_SHORT).show()
                navigateFragments(view, R.id.action_loginFragment_to_homeFragment)

            }
            .addOnFailureListener{e->
                progressDialog.dismiss()
                Toast.makeText(context,"Login failed due to ${e.message}",Toast.LENGTH_SHORT)
            }


    }
}