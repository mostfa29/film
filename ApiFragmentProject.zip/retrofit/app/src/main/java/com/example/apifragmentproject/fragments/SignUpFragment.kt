package  com.example.apifragmentproject.fragments

import android.app.ProgressDialog
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.Navigation
import com.example.apifragmentproject.R
import com.example.apifragmentproject.databinding.FragmentSignUpBinding
import com.google.firebase.auth.FirebaseAuth

class SignUpFragment : Fragment() {
    private lateinit var binding: FragmentSignUpBinding


    private lateinit var progressDialog: ProgressDialog
    private lateinit var firebaseAuth: FirebaseAuth
    private var email = ""
    private var password = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {




        binding= FragmentSignUpBinding.inflate(layoutInflater)
        //configure progress Dialog

        progressDialog = ProgressDialog(context)
        progressDialog.setTitle("Please wait")
        progressDialog.setMessage("sign up...")
        progressDialog.setCanceledOnTouchOutside((false))

        //init firebaseAuth
        firebaseAuth = FirebaseAuth.getInstance()


        return binding.root


    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.SignUp.setOnClickListener {
            validateData(view)
        }
    }

    private fun validateData(view:View) {
        //get data
        email = binding.email.text.toString().trim()
        password = binding.password.text.toString().trim()
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.email.error = "Invalid email format"
        } else if (TextUtils.isEmpty(password)) {
            binding.password.error = "Please enter password"
        }else if(password.length<6){
            binding.password.error="password length must be over 6 characters"
        }
        else {
            firebaseSignUp(view)

        }

    }

    private fun firebaseSignUp(view: View) {
        progressDialog.show()
        firebaseAuth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                progressDialog.dismiss()
                val firebaseUser = firebaseAuth.currentUser
                val email = firebaseUser!!.email
                Toast.makeText(context, "account created with email: $email", Toast.LENGTH_SHORT).show()
                navigateFragments(view, R.id.action_signUpFragment_to_loginFragment)

            }
            .addOnFailureListener{e->
                progressDialog.dismiss()
                Toast.makeText(context,"sign up failed due to ${e.message}", Toast.LENGTH_SHORT)
            }
    }


    private fun navigateFragments(view: View, frag: Int) {
        Navigation.findNavController(view)
            .navigate(frag)
    }


}